/* pkcs12.h for libcurl */


#undef HAVE_OPENSSL_PKCS12_H

